/*
 * Document: MyPage.java
 * Unitec Institute of Technology
 * @authors Natasha Bettridge, Taylor Tran and Michael Yin
 * Document: contains database connect
 */

/**
 *
 * @author Natasha Bettridge, Taylor Tran, Michael Yin
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbconnect {
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=BankingDB;encrypt=true;trustServerCertificate=true";
    private static final String USER = "root";  // Change this
    private static final String PASSWORD = "";  // Change this

    public static Connection connectDb() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to SQL Server!");
            return conn;
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            return null;
        }
    }
}

